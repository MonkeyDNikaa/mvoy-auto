package fr.mvoy.auto

import android.content.ContentUris
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

class MvoyMediaLibraryService : MediaLibraryService() {
    private var session: MediaLibrarySession?=null
    private lateinit var player: ExoPlayer
    override fun onCreate(){super.onCreate();player=ExoPlayer.Builder(this).build()
        val callback=object:MediaLibrarySession.Callback {
            override fun onGetLibraryRoot(s:MediaLibrarySession,b:MediaSession.ControllerInfo,params:LibraryParams?):ListenableFuture<LibraryResult<MediaItem>> {
                val root=MediaItem.Builder().setMediaId(ROOT).setMediaMetadata(MediaMetadata.Builder().setTitle("MVOY PLAYER").setIsBrowsable(true).setIsPlayable(false).build()).build()
                return Futures.immediateFuture(LibraryResult.ofItem(root,params))
            }
            override fun onGetChildren(s:MediaLibrarySession,b:MediaSession.ControllerInfo,parentId:String,page:Int,pageSize:Int,params:LibraryParams?):ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
                return Futures.immediateFuture(LibraryResult.ofItemList(if(parentId==ROOT)audio(page,pageSize) else mutableListOf(),params))
            }
        }
        session=MediaLibrarySession.Builder(this,player,callback).build()
    }
    private fun audio(page:Int,size:Int):MutableList<MediaItem>{
        val out=mutableListOf<MediaItem>();val projection=arrayOf(MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST,MediaStore.Audio.Media.ALBUM)
        val c=contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,projection,"${MediaStore.Audio.Media.IS_MUSIC} != 0",null,"${MediaStore.Audio.Media.TITLE} ASC LIMIT $size OFFSET ${page*size}")
        c?.use { cur -> val id=cur.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);val title=cur.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);val artist=cur.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);val album=cur.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            while(cur.moveToNext()){val uri=ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,cur.getLong(id));val meta=MediaMetadata.Builder().setTitle(cur.getString(title)?:"Titre inconnu").setArtist(cur.getString(artist)?:"Artiste inconnu").setAlbumTitle(cur.getString(album)?:"").setIsPlayable(true).build();out.add(MediaItem.Builder().setMediaId(uri.toString()).setUri(uri).setMediaMetadata(meta).build())}
        };return out
    }
    override fun onGetSession(controllerInfo:MediaSession.ControllerInfo)=session
    override fun onDestroy(){session?.release();player.release();session=null;super.onDestroy()}
    companion object {private const val ROOT="mvoy_audio_root"}
}
