package fr.bower.driver

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("bower_local", MODE_PRIVATE) }
    private val ink = Color.rgb(27, 48, 55)
    private val teal = Color.rgb(22, 125, 120)
    private val muted = Color.rgb(105, 124, 128)
    private val bg = Color.rgb(246, 249, 248)
    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 14)
            setBackgroundColor(Color.WHITE)
        }
        header.addView(label("BOWER", 25, ink, true))
        header.addView(label("L'assistant des chauffeurs", 13, muted))
        root.addView(header)

        val scroll = ScrollView(this)
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 20)
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            setBackgroundColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(4, 8, 4, 8)
        }
        listOf("Accueil", "Carte", "Communauté", "Revenus", "Profil").forEach { name ->
            nav.addView(TextView(this).apply {
                text = name
                textSize = 11f
                gravity = Gravity.CENTER
                setPadding(4, 10, 4, 10)
                setTextColor(if (name == "Accueil") teal else muted)
                setOnClickListener { showTab(name) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
        showTab("Accueil")
        requestLocation()
    }

    private fun showTab(name: String) {
        body.removeAllViews()
        when (name) {
            "Accueil" -> dashboard()
            "Carte" -> mapScreen()
            "Communauté" -> community()
            "Revenus" -> earnings()
            else -> profile()
        }
    }

    private fun dashboard() {
        body.addView(label("Bonjour 👋", 25, ink, true))
        body.addView(label("Votre activité, en un coup d'œil.", 14, muted))
        body.addView(space(14))
        val d = JSONObject(prefs.getString("today", "{}") ?: "{}")
        val revenue = d.optDouble("revenue")
        val km = d.optDouble("km")
        val costs = d.optDouble("costs")
        card {
            addView(label("NET ESTIMÉ AUJOURD'HUI", 11, muted, true))
            addView(label(money(revenue - costs), 34, teal, true))
            addView(label("Selon les données saisies", 12, muted))
        }
        body.addView(space(12))
        val metrics = LinearLayout(this)
        metrics.addView(metric("Chiffre d'affaires", money(revenue)), LinearLayout.LayoutParams(0, -2, 1f))
        metrics.addView(metric("Kilomètres", String.format(Locale.FRANCE, "%.1f km", km)), LinearLayout.LayoutParams(0, -2, 1f))
        body.addView(metrics)
        body.addView(space(12))
        section("Accès rapide")
        actionCard("Calculer ma rentabilité", "Charges, carburant et bénéfice net") { showTab("Revenus") }
        actionCard("Ouvrir la carte", "Carte OpenStreetMap") { showTab("Carte") }
        actionCard("Créer un signalement", "Carnet local sur cet appareil") { showTab("Communauté") }
    }

    private fun earnings() {
        body.addView(label("Rentabilité", 25, ink, true))
        body.addView(label("Estimez le bénéfice après vos frais.", 13, muted))
        val revenue = edit("Chiffre d'affaires (€)", "revenue", "180")
        val km = edit("Kilomètres parcourus", "km", "140")
        val consumption = edit("Consommation (L / 100 km)", "consumption", prefs.getString("consumption", "7.0") ?: "7.0")
        val fuel = edit("Prix carburant (€/L)", "fuel", "1.85")
        val other = edit("Autres frais (€)", "other", "12")
        val wear = edit("Usure / entretien (€ par km)", "wear", "0.08")
        val result = label("", 24, teal, true)
        body.addView(result)
        fun calculate() {
            val r = revenue.text.toString().toDoubleOrNull() ?: 0.0
            val k = km.text.toString().toDoubleOrNull() ?: 0.0
            val c = consumption.text.toString().toDoubleOrNull() ?: 0.0
            val f = fuel.text.toString().toDoubleOrNull() ?: 0.0
            val o = other.text.toString().toDoubleOrNull() ?: 0.0
            val w = wear.text.toString().toDoubleOrNull() ?: 0.0
            val total = k * c / 100 * f + o + k * w
            result.text = "Résultat estimé : ${money(r - total)}"
            prefs.edit()
                .putString("today", JSONObject().put("revenue", r).put("km", k).put("costs", total).toString())
                .putString("consumption", consumption.text.toString())
                .apply()
        }
        body.addView(button("Calculer et enregistrer") {
            calculate()
            Toast.makeText(this, "Enregistré sur ce téléphone", Toast.LENGTH_SHORT).show()
        })
        calculate()
        body.addView(label("Stockage local uniquement : aucune synchronisation cloud n'est configurée.", 12, muted))
    }

    private fun mapScreen() {
        body.addView(label("Carte", 25, ink, true))
        body.addView(label("OpenStreetMap. Les marqueurs BOWER partagés et le suivi GPS ne sont pas activés.", 13, muted))
        val map = WebView(this)
        map.settings.javaScriptEnabled = true
        map.webViewClient = WebViewClient()
        map.loadUrl("https://www.openstreetmap.org")
        body.addView(map, LinearLayout.LayoutParams(-1, 520))
        body.addView(button("Ouvrir OpenStreetMap") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.openstreetmap.org")))
        })
    }

    private fun community() {
        body.addView(label("Communauté", 25, ink, true))
        body.addView(label("Carnet local. Les signalements ne sont pas transmis aux autres chauffeurs.", 13, muted))
        val types = listOf("Contrôle", "Accident", "Route fermée", "Zone d'attente", "Danger", "Autre")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)
        body.addView(spinner)
        val note = EditText(this).apply {
            hint = "Description"
            minLines = 3
            gravity = Gravity.TOP
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.WHITE)
        }
        body.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        body.addView(button("Enregistrer le signalement") {
            val reports = JSONArray(prefs.getString("reports", "[]") ?: "[]")
            reports.put(JSONObject()
                .put("type", types[spinner.selectedItemPosition])
                .put("note", note.text.toString())
                .put("time", System.currentTimeMillis()))
            prefs.edit().putString("reports", reports.toString()).apply()
            note.setText("")
            showTab("Communauté")
            Toast.makeText(this, "Enregistré localement", Toast.LENGTH_SHORT).show()
        })
        body.addView(space(14))
        section("Mes signalements")
        val reports = JSONArray(prefs.getString("reports", "[]") ?: "[]")
        if (reports.length() == 0) body.addView(label("Aucun signalement.", 13, muted))
        for (i in reports.length() - 1 downTo 0) {
            val item = reports.optJSONObject(i) ?: continue
            actionCard(item.optString("type"), item.optString("note").ifBlank { "Sans description" }) {}
        }
    }

    private fun profile() {
        body.addView(label("Mon profil", 25, ink, true))
        val vehicle = edit("Véhicule", "vehicle", "Berline")
        val energy = edit("Motorisation", "energy", "Essence")
        val consumption = edit("Consommation (L / 100 km)", "consumption", "7.0")
        body.addView(button("Enregistrer mon véhicule") {
            prefs.edit()
                .putString("vehicle", vehicle.text.toString())
                .putString("energy", energy.text.toString())
                .putString("consumption", consumption.text.toString())
                .apply()
            Toast.makeText(this, "Profil enregistré", Toast.LENGTH_SHORT).show()
        })
        body.addView(space(12))
        actionCard("Confidentialité", "Les données restent sur cet appareil.") {}
        actionCard("Android Auto", "Service natif AndroidX Car App Library • catégorie POI") {}
        actionCard("Version", "BOWER 1.0.0 • mode local") {}
    }

    private fun edit(title: String, key: String, default: String): EditText {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 9, 0, 2)
        }
        container.addView(label(title, 13, muted, true))
        val field = EditText(this).apply {
            inputType = if (key == "vehicle" || key == "energy") InputType.TYPE_CLASS_TEXT
            else InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            textSize = 16f
            setText(prefs.getString(key, default) ?: default)
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.WHITE)
        }
        container.addView(field)
        body.addView(container)
        return field
    }

    private fun metric(title: String, value: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(14, 14, 8, 14)
        setBackgroundColor(Color.WHITE)
        addView(label(title, 11, muted))
        addView(label(value, 19, ink, true))
    }

    private fun card(content: LinearLayout.() -> Unit) {
        body.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.WHITE)
            content()
        })
    }

    private fun actionCard(title: String, subtitle: String, action: () -> Unit) {
        body.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(15, 14, 15, 14)
            setBackgroundColor(Color.WHITE)
            addView(label(title, 15, ink, true))
            addView(label(subtitle, 12, muted))
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 })
    }

    private fun section(title: String) {
        body.addView(label(title, 17, ink, true))
        body.addView(space(8))
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }

    private fun button(title: String, action: () -> Unit) = Button(this).apply {
        text = title
        setTextColor(Color.WHITE)
        setBackgroundColor(teal)
        setOnClickListener { action() }
    }

    private fun money(value: Double) = NumberFormat.getCurrencyInstance(Locale.FRANCE).format(value)

    private fun requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 20)
        }
    }
}
