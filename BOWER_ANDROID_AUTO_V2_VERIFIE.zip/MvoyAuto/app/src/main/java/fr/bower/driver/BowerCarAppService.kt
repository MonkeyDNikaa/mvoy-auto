package fr.bower.driver

import androidx.car.app.CarAppService
import androidx.car.app.Session
import androidx.car.app.Screen
import androidx.car.app.validation.HostValidator
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template

class BowerCarAppService : CarAppService() {
    // Debug/sideload test host. A production Play release must apply Google's host validation policy.
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = BowerCarSession()
}

class BowerCarSession : Session() {
    override fun onCreateScreen(intent: android.content.Intent): Screen = BowerCarScreen(carContext)
}

class BowerCarScreen(carContext: androidx.car.app.CarContext) : Screen(carContext) {
    override fun onGetTemplate(): Template {
        val entries = listOf(
            "Carte et points d'intérêt" to "Repères utiles pour les chauffeurs",
            "Stations-service" to "Trouver une station à proximité",
            "Aires de repos" to "Choisir un lieu pour faire une pause",
            "Zones de prise en charge" to "Repères enregistrés dans BOWER",
            "Signalements" to "Le partage entre chauffeurs nécessite le service en ligne"
        )
        val items = ItemList.Builder()
        entries.forEach { (title, detail) ->
            items.addItem(Row.Builder().setTitle(title).addText(detail).build())
        }
        val refresh = Action.Builder()
            .setTitle("Actualiser")
            .setOnClickListener { invalidate() }
            .build()
        return ListTemplate.Builder()
            .setTitle("BOWER")
            .setHeaderAction(Action.APP_ICON)
            .setActionStrip(ActionStrip.Builder().addAction(refresh).build())
            .setSingleList(items.build())
            .build()
    }
}
