# BOWER Android

Native Android driver companion with a light UI, local earnings calculator, OpenStreetMap view, local report notebook and AndroidX Car App Library POI service.

## Current scope
- Earnings, vehicle settings and reports are stored locally.
- Reports are NOT shared between drivers: no backend/account/cloud credentials are configured.
- Map opens OpenStreetMap; live tracking and BOWER shared map markers are not implemented.
- Android Auto exposes a native POI list template. Launcher visibility depends on host compatibility and Google's distribution/quality rules.
- Validate on a physical phone and Android Auto DHU/vehicle before claiming compatibility.

## Build
GitHub Actions builds a debug APK with Java 17.
