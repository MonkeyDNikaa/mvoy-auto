plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.bower.app"; compileSdk=35; defaultConfig { applicationId="com.bower.app"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0" } }
dependencies { implementation("org.osmdroid:osmdroid-android:6.1.20"); implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.car.app:app:1.7.0") }
