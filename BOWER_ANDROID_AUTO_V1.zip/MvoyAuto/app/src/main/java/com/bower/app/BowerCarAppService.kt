package com.bower.app
import android.content.Intent
import androidx.car.app.CarAppService
import androidx.car.app.Session
import androidx.car.app.Screen
import androidx.car.app.CarContext
import androidx.car.app.model.Action
import androidx.car.app.model.ItemList
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.car.app.model.ListTemplate
import androidx.car.app.validation.HostValidator

class BowerCarAppService : CarAppService() {
 override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
 override fun onCreateSession(): Session = BowerCarSession()
}
class BowerCarSession : Session() {
 override fun onCreateScreen(intent: Intent): Screen = BowerCarScreen(carContext)
}
class BowerCarScreen(carContext: CarContext) : Screen(carContext) {
 override fun onGetTemplate(): Template {
  val reports=Store(carContext).all()
  val rows=ItemList.Builder()
  if(reports.isEmpty()) rows.addItem(Row.Builder().setTitle("Aucun signalement").addText("Ouvre BOWER sur le téléphone pour publier ou consulter les signalements.").build())
  else reports.take(20).forEach { r ->
   val title=if(r.type=="BOWER" && r.up>=11) "💣 BOWER confirmé" else r.type
   rows.addItem(Row.Builder().setTitle(title).addText(r.detail.take(100)).addText("Par ${r.author} • 👍 ${r.up} • 👎 ${r.down}").build())
  }
  return ListTemplate.Builder().setTitle("BOWER • Signalements").setHeaderAction(Action.APP_ICON).setSingleList(rows.build()).build()
 }
}
