package com.bower.app
import android.Manifest
import android.app.*
import android.os.Bundle
import android.content.*
import android.content.pm.PackageManager
import android.database.sqlite.*
import android.graphics.Color
import android.location.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
data class Report(val id:Long,val type:String,val detail:String,val lat:Double,val lon:Double,val author:String,val up:Int,val down:Int)
class Store(c:android.content.Context):SQLiteOpenHelper(c,"bower.db",null,1){
 override fun onCreate(d:SQLiteDatabase){d.execSQL("CREATE TABLE reports(id INTEGER PRIMARY KEY,type TEXT,detail TEXT,lat REAL,lon REAL,author TEXT,up INTEGER DEFAULT 0,down INTEGER DEFAULT 0)");d.execSQL("CREATE TABLE votes(id INTEGER PRIMARY KEY,vote INTEGER)")}
 override fun onUpgrade(d:SQLiteDatabase,o:Int,n:Int){}
 fun add(t:String,s:String,l:Location,a:String){writableDatabase.insert("reports",null,ContentValues().apply{put("type",t);put("detail",s);put("lat",l.latitude);put("lon",l.longitude);put("author",a)})}
 fun all():List<Report>{val x=mutableListOf<Report>();readableDatabase.rawQuery("SELECT * FROM reports ORDER BY id DESC",null).use{while(it.moveToNext())x.add(Report(it.getLong(0),it.getString(1),it.getString(2),it.getDouble(3),it.getDouble(4),it.getString(5),it.getInt(6),it.getInt(7)))};return x}
 fun vote(id:Long,v:Int){val d=writableDatabase;val old=d.rawQuery("SELECT vote FROM votes WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getInt(0) else 0};if(old==v)return;if(old!=0)d.execSQL("UPDATE reports SET up=up-?,down=down-? WHERE id=?",arrayOf(if(old==1)1 else 0,if(old==-1)1 else 0,id));d.execSQL("INSERT OR REPLACE INTO votes(id,vote) VALUES(?,?)",arrayOf(id,v));d.execSQL("UPDATE reports SET up=up+?,down=down+? WHERE id=?",arrayOf(if(v==1)1 else 0,if(v==-1)1 else 0,id))}
}
class MainActivity:Activity(),LocationListener{
 lateinit var store:Store;lateinit var body:LinearLayout;var map:MapView?=null;var gps:Location?=null;var radius=20;var fuel=1.75;var cons=6.0;var vehicle="Diesel";var pseudo="Chauffeur BOWER"
 val pref by lazy{getSharedPreferences("p",0)}
 override fun onCreate(b:Bundle?){super.onCreate(b);Configuration.getInstance().userAgentValue=packageName;store=Store(this);radius=pref.getInt("r",20);fuel=pref.getString("f","1.75")!!.toDouble();cons=pref.getString("c","6")!!.toDouble();vehicle=pref.getString("v","Diesel")!!;pseudo=pref.getString("n","Chauffeur BOWER")!!;home();locate()}
 fun base(t:String){val root=LinearLayout(this).apply{orientation=1;setBackgroundColor(Color.rgb(15,18,24))};root.addView(TextView(this).apply{text=t;textSize=25f;setTextColor(-1);setPadding(18,18,10,12)});val nav=LinearLayout(this);listOf("Accueil","Carte","Calcul","Paramètres").forEach{n->nav.addView(Button(this).apply{text=n;textSize=10f;setOnClickListener{when(n){"Accueil"->home();"Carte"->mapScreen();"Calcul"->calculator();else->settings()}}},LinearLayout.LayoutParams(0,50,1f))};root.addView(nav);val sc=ScrollView(this);body=LinearLayout(this).apply{orientation=1;setPadding(16,8,16,20)};sc.addView(body);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)}
 fun label(s:String,z:Float=16f)=TextView(this).apply{text=s;textSize=z;setTextColor(-1);setPadding(4,9,4,9)}
 fun edit(h:String,v:String="")=EditText(this).apply{hint=h;setText(v);setTextColor(-1);setHintTextColor(0xffaaaaaa.toInt());setSingleLine(true)}
 fun btn(s:String,f:()->Unit)=Button(this).apply{text=s;setOnClickListener{f()}}
 fun home(){base("BOWER");body.addView(label("Assistant VTC • Uber + Bolt"));body.addView(label("Véhicule $vehicle • $cons /100 • $fuel €/unité"));body.addView(btn("Carte communautaire"){mapScreen()});body.addView(btn("Créer un signalement"){newReport()});body.addView(btn("Calculer une course"){calculator()});body.addView(label("Android Auto : ouvre BOWER dans le lanceur de la voiture pour consulter les signalements enregistrés localement.",13f))}
 fun mapScreen(){base("BOWER COMMUNITY");body.addView(label("Rayon $radius km • GPS requis"));val m=MapView(this);map=m;m.setTileSource(TileSourceFactory.MAPNIK);m.setMultiTouchControls(true);m.controller.setZoom(12.0);val l=gps;m.controller.setCenter(if(l!=null)GeoPoint(l.latitude,l.longitude) else GeoPoint(46.6,2.4));body.addView(m,LinearLayout.LayoutParams(-1,560));body.addView(btn("+ Signalement"){newReport()});pins()}
 fun pins(){val m=map?:return;m.overlays.clear();store.all().forEach{r->val l=gps;val d=FloatArray(1);if(l!=null)Location.distanceBetween(l.latitude,l.longitude,r.lat,r.lon,d);if(l==null||d[0]<=radius*1000){val p=Marker(m);p.position=GeoPoint(r.lat,r.lon);p.title(if(r.type=="BOWER"&&r.up>=11)"💣 BOWER confirmé" else r.type);p.snippet("${r.detail}\n${r.author} • 👍${r.up} 👎${r.down}");p.setOnMarkerClickListener{_,_->AlertDialog.Builder(this).setTitle(p.title).setMessage(p.snippet).setPositiveButton("👍"){_,_->store.vote(r.id,1);pins()}.setNegativeButton("👎"){_,_->store.vote(r.id,-1);pins()}.setNeutralButton("Fermer",null).show();true};m.overlays.add(p)}};m.invalidate()}
 fun newReport(){val types=arrayOf("BOWER","Demande","Trafic","Événement","Danger","Contrôle");AlertDialog.Builder(this).setTitle("Signalement").setItems(types){_,i->val e=edit("Description factuelle");AlertDialog.Builder(this).setTitle(types[i]).setView(e).setPositiveButton("Publier"){_,_->val l=gps;if(l==null){toast("GPS indisponible");return@setPositiveButton};if(e.text.isBlank()){toast("Description requise");return@setPositiveButton};store.add(types[i],e.text.toString(),l,pseudo);toast("Enregistré sur ce téléphone");mapScreen()}.setNegativeButton("Annuler",null).show()}.show()}
 fun calculator(){base("Analyse de course");val p=edit("Prix proposé (€)");val k=edit("Distance totale (km)");val t=edit("Durée (minutes)");body.addView(p);body.addView(k);body.addView(t);val out=label("Résultat en attente");body.addView(btn("Calculer"){val a=p.text.toString().toDoubleOrNull();val b=k.text.toString().toDoubleOrNull();val c=t.text.toString().toDoubleOrNull();if(a==null||b==null||c==null||b<=0||c<=0){out.text="Valeurs invalides";return@btn};val cost=b*cons/100*fuel;val net=a-cost;out.text="Énergie : %.2f €\nReste avant autres frais : %.2f €\nEstimation horaire : %.2f €/h".format(cost,net,net/(c/60))});body.addView(out)}
 fun settings(){base("Paramètres");val sp=Spinner(this);val types=listOf("Diesel","Essence","Hybride","Électrique","GPL");sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,types);sp.setSelection(types.indexOf(vehicle).coerceAtLeast(0));body.addView(sp);val c=edit("Consommation /100 km",cons.toString());val f=edit("Prix énergie",fuel.toString());val r=edit("Rayon km",radius.toString());val n=edit("Pseudo",pseudo);listOf(c,f,r,n).forEach{body.addView(it)};body.addView(btn("Enregistrer"){val cv=c.text.toString().toDoubleOrNull();val fv=f.text.toString().toDoubleOrNull();val rv=r.text.toString().toIntOrNull();if(cv==null||fv==null||rv==null||cv<=0||fv<=0||rv !in 1..200){toast("Valeurs invalides");return@btn};vehicle=sp.selectedItem.toString();cons=cv;fuel=fv;radius=rv;pseudo=n.text.toString().ifBlank{"Chauffeur BOWER"};pref.edit().putString("v",vehicle).putString("c","$cv").putString("f","$fv").putInt("r",rv).putString("n",pseudo).apply();home()})}
 fun locate(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),9);return};try{val lm=getSystemService(LOCATION_SERVICE) as LocationManager;gps=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?:lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,10000,50f,this)}catch(_:Exception){}}
 override fun onLocationChanged(l:Location){gps=l;if(map!=null)pins()}
 override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==9&&g.any{it==PackageManager.PERMISSION_GRANTED})locate()else toast("Autorise la localisation")}
 override fun onResume(){super.onResume();map?.onResume()}
 override fun onPause(){map?.onPause();super.onPause()}
 fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
