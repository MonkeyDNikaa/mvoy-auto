# BOWER V1 Android + Android Auto
Android Auto : service CarAppService de catégorie POI et interface officielle ListTemplate. L'écran embarqué liste jusqu'à 20 signalements enregistrés localement avec catégorie, texte, auteur et compteurs. Les signalements BOWER ayant au moins 11 votes positifs portent le libellé 💣.
Téléphone : carte OSM, GPS, rayon paramétrable, création de signalements, votes, paramètres véhicule et calcul manuel d'énergie.
LIMITES : pas de carte avec pins sur l'écran voiture dans cette première intégration; pas de synchronisation serveur entre chauffeurs; pas de scanner automatique des offres Uber/Bolt. L'apparition sur Android Auto doit être validée par compilation et essai sur véhicule/DHU; disponibilité soumise aux règles Google et au processus d'approbation.
