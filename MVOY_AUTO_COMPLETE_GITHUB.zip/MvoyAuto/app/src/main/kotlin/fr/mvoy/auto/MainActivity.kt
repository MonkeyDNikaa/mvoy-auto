package fr.mvoy.auto

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CalendarContract
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private val bg = Color.rgb(8,8,8); private val panel = Color.rgb(25,25,25); private val white = Color.WHITE; private val muted = Color.LTGRAY
    private val prefs by lazy { getSharedPreferences("mvoy_business", MODE_PRIVATE) }
    private lateinit var page: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); renderHome(); askAudioPermission() }
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    private fun label(s:String, size:Float, color:Int, bold:Boolean=false)=TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold)setTypeface(null,1) }
    private fun root()=LinearLayout(this).apply { orientation=1; setPadding(dp(20),dp(24),dp(20),dp(24)); setBackgroundColor(bg) }
    private fun renderHome() {
        page=root(); val scroll=ScrollView(this); scroll.addView(page)
        page.addView(label("MVOY AUTO",30f,white,true).apply{letterSpacing=.16f})
        page.addView(label("YOUR DRIVE. YOUR FLOW.",11f,muted,true).apply{setPadding(0,dp(4),0,dp(22))})
        card("MVOY PLAYER","Bibliothèque audio locale • Android Auto"){showPlayer()}
        card("MVOY TUBE","Ouvrir SmartTube sur le téléphone"){openSmartTube()}
        card("MVOY ASSIST","Ouvrir ton application ChatGPT existante"){openChatGPT()}
        card("MVOY NAV","Google Maps • Waze"){showNav()}
        card("MVOY BUSINESS","Notes • rappels • rendez-vous"){showBusiness()}
        card("MVOY SETTINGS","Permissions • configuration"){showSettings()}
        page.addView(label("Sur Android Auto, seul le lecteur audio est présenté dans l'interface Médias. Les autres modules s'utilisent sur le téléphone à l'arrêt. Pas de vidéo projetée pendant la conduite.",12f,muted).apply{setPadding(0,dp(16),0,0)})
        setContentView(scroll)
    }
    private fun card(title:String, desc:String, action:()->Unit) {
        val box=LinearLayout(this).apply { orientation=1; setPadding(dp(18),dp(16),dp(18),dp(16)); setBackgroundColor(panel); isClickable=true; isFocusable=true; setOnClickListener{action()} }
        box.addView(label(title,17f,white,true)); box.addView(label(desc,12f,muted).apply{setPadding(0,dp(6),0,0)})
        page.addView(box,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})
    }
    private fun show(title:String, desc:String, block:(LinearLayout)->Unit) {
        page.removeAllViews(); page.addView(label("‹  ACCUEIL",14f,muted).apply{setPadding(0,0,0,dp(18));setOnClickListener{renderHome()}})
        page.addView(label(title,25f,white,true)); page.addView(label(desc,13f,muted).apply{setPadding(0,dp(6),0,dp(18))}); block(page)
    }
    private fun button(p:LinearLayout, s:String, action:()->Unit) { p.addView(Button(this).apply{text=s;isAllCaps=false;setTextColor(white);setBackgroundColor(panel);setOnClickListener{action()}},LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)}) }
    private fun showPlayer()=show("MVOY PLAYER","La bibliothèque locale est exposée au système Android Auto.") { p ->
        button(p,"Autoriser la musique / actualiser"){askAudioPermission();toast("Puis ouvre Android Auto > Médias > MVOY AUTO.")}
        button(p,"Paramètres de l'application"){startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")))}
        p.addView(label("MVOY PLAYER lit les fichiers audio présents sur ton téléphone. Aucun morceau n'est fourni dans l'application.",13f,muted))
    }
    private fun openSmartTube() {
        val intent=packageManager.getLaunchIntentForPackage("com.teamsmart.videomanager.tv") ?: packageManager.getLaunchIntentForPackage("com.teamsmart.videomanager")
        if(intent!=null)startActivity(intent) else {toast("SmartTube non détecté. Ouverture de sa source officielle.");view("https://github.com/yuliskov/SmartTube")}
    }
    private fun openChatGPT() { val i=packageManager.getLaunchIntentForPackage("com.openai.chatgpt"); if(i!=null)startActivity(i) else view("https://play.google.com/store/apps/details?id=com.openai.chatgpt") }
    private fun showNav()=show("MVOY NAV","Choisis ton application de navigation.") { p -> button(p,"Google Maps"){view("google.navigation:q=")}; button(p,"Waze"){view("https://waze.com/ul")} }
    private fun showBusiness()=show("MVOY BUSINESS","Notes stockées localement sur ton téléphone.") { p ->
        val input=EditText(this).apply{setText(prefs.getString("note",""));hint="Note ou rappel…";setTextColor(white);setHintTextColor(muted);setBackgroundColor(panel);minLines=4;gravity=Gravity.TOP}
        p.addView(input,LinearLayout.LayoutParams(-1,dp(130)))
        button(p,"Enregistrer la note"){prefs.edit().putString("note",input.text.toString()).apply();toast("Note enregistrée.")}
        button(p,"Créer un rendez-vous calendrier"){val i=Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).putExtra(CalendarContract.Events.TITLE,"Rendez-vous MVOY");if(i.resolveActivity(packageManager)!=null)startActivity(i)else toast("Calendrier indisponible.")}
    }
    private fun showSettings()=show("MVOY SETTINGS","Configuration système.") { p -> button(p,"Autorisation audio"){askAudioPermission()};button(p,"Réglages Android de MVOY AUTO"){startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")))};p.addView(label("Version 1.0.0 • Thème sombre • Media3 • Android Auto Media.",13f,muted)) }
    private fun askAudioPermission() { val perm=if(Build.VERSION.SDK_INT>=33)Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE; if(ContextCompat.checkSelfPermission(this,perm)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(perm),410) }
    private fun view(url:String){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}catch(_:Exception){toast("Lien ou application indisponible.")}}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
