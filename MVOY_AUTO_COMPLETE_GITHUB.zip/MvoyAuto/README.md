# MVOY AUTO — projet Android compagnon

Modules : PLAYER (fichiers audio locaux + Media3/Android Auto), TUBE (ouvre SmartTube installé), ASSIST (ouvre l'application ChatGPT officielle), NAV (Google Maps/Waze), BUSINESS (notes locales + création de rendez-vous calendrier), SETTINGS (permissions et réglages).

## Important — périmètre réel
- Le service Android Auto expose le lecteur audio dans la catégorie Médias. Android Auto n'autorise pas une interface arbitraire de modules sur l'écran voiture.
- SmartTube/YouTube vidéo n'est pas projeté sur l'écran Android Auto pendant la conduite.
- ASSIST ouvre l'application ChatGPT existante ; aucune API ChatGPT séparée n'est intégrée. Les fonctions vocales dépendent de l'application et des règles Android Auto.
- Le lecteur lit les fichiers audio locaux autorisés ; aucune musique n'est fournie.
- Le code doit encore être compilé et testé sur un appareil réel. Ce ZIP est un projet source fonctionnellement structuré, pas un APK certifié ni une validation Android Auto.

## Build
JDK 17, Android SDK 35, Gradle 8.9, Android Gradle Plugin 8.7.3. Commande : `gradle assembleDebug`. APK attendu : `app/build/outputs/apk/debug/app-debug.apk`.
