package com.bower.app

import androidx.car.app.CarAppService
import androidx.car.app.Session
import androidx.car.app.Screen
import androidx.car.app.validation.HostValidator
import androidx.car.app.model.ItemList
import androidx.car.app.model.Row
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Template
import androidx.car.app.model.Action
import androidx.car.app.model.Header
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarText

class BowerCarAppService : CarAppService() {
    override fun createHostValidator(): HostValidator =
        HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(): Session = object : Session() {
        override fun onCreateScreen(intent: android.content.Intent): Screen =
            BowerCarScreen(carContext)
    }
}

private class BowerCarScreen(carContext: androidx.car.app.CarContext) : Screen(carContext) {
    override fun onGetTemplate(): Template {
        val items = ItemList.Builder()
            .addItem(Row.Builder().setTitle("BOWER").addText("Assistant conducteur").build())
            .addItem(Row.Builder().setTitle("Calcul de rentabilité").addText("Utilise l'application sur ton téléphone pour calculer une course").build())
            .addItem(Row.Builder().setTitle("Signalements").addText("Les alertes communautaires seront disponibles dans une prochaine version").build())
            .build()
        return ListTemplate.Builder()
            .setTitle("BOWER")
            .setHeaderAction(Action.APP_ICON)
            .setSingleList(items)
            .build()
    }
}
