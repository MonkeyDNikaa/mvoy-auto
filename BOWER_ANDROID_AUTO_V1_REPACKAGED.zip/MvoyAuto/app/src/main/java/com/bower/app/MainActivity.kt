package com.bower.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.text.InputType
import java.util.Locale

class MainActivity : Activity() {
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(Color.rgb(16, 24, 32))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "BOWER"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        content.addView(title)
        val subtitle = TextView(this).apply {
            text = "Ton copilote de rentabilité"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(20))
        }
        content.addView(subtitle)

        fun label(value: String) {
            content.addView(TextView(this).apply {
                text = value
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(0, dp(12), 0, dp(5))
            })
        }
        fun field(hint: String, value: String): EditText {
            return EditText(this).apply {
                this.hint = hint
                setSingleLine(true)
                setText(value)
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setBackgroundColor(Color.rgb(38, 50, 60))
            }.also { content.addView(it) }
        }

        label("Véhicule")
        val vehicle = Spinner(this)
        vehicle.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Diesel", "Essence", "Hybride", "Électrique", "GPL"))
        content.addView(vehicle)

        label("Consommation (L/100 km ou kWh/100 km)")
        val consumption = field("Ex. 6.5", "6.5")
        label("Prix du carburant / kWh (€)")
        val energyPrice = field("Ex. 1.75", "1.75")
        label("Distance de la course (km)")
        val distance = field("Ex. 12", "12")
        label("Prix proposé par la plateforme (€)")
        val fare = field("Ex. 18", "18")

        val result = TextView(this).apply {
            text = "Renseigne les valeurs puis calcule ta rentabilité."
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(0, dp(20), 0, dp(12))
        }
        content.addView(result)

        val calculate = Button(this).apply {
            text = "CALCULER LA RENTABILITÉ"
            setOnClickListener {
                val c = consumption.text.toString().toDoubleOrNull()
                val p = energyPrice.text.toString().toDoubleOrNull()
                val d = distance.text.toString().toDoubleOrNull()
                val f = fare.text.toString().toDoubleOrNull()
                if (c == null || p == null || d == null || f == null || c < 0 || p < 0 || d <= 0) {
                    result.text = "Vérifie les valeurs saisies."
                } else {
                    val cost = (c / 100.0) * d * p
                    val net = f - cost
                    val perKm = net / d
                    result.text = String.format(Locale.FRANCE,
                        "Coût énergie : %.2f €\nReste après énergie : %.2f €\nRentabilité : %.2f €/km",
                        cost, net, perKm)
                }
            }
        }
        content.addView(calculate)

        val note = TextView(this).apply {
            text = "\nBOWER V1 — calcul manuel. Les résultats ne comprennent pas l'usure, l'assurance, les charges ni les commissions éventuelles. Les signalements communautaires et la synchronisation en ligne ne sont pas activés dans cette version."
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }
        content.addView(note)
        root.addView(scroll)
        setContentView(root)
    }
}
