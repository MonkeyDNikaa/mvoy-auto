# BOWER Android V1

Version de base compilable de BOWER :
- application Android avec calcul manuel du coût énergie et du reste après énergie ;
- choix du type de véhicule ;
- service Android Auto de catégorie POI affichant une liste informative.

Limites connues de cette V1 :
- pas de compte ni de synchronisation cloud ;
- pas de signalements communautaires partagés ;
- pas de carte ni de navigation interactive sur Android Auto ;
- le calcul n'inclut pas les frais d'usure, assurance, commissions ou autres charges ;
- Android Auto doit être testé sur un véhicule/émulateur compatible et reste soumis aux règles et validations Google.

Le service Android Auto est une première intégration de liste, pas une interface de carte personnalisée.
